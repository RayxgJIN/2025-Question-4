# src/jpm_q4/bonus_ceo_board/features.py
import pandas as pd

def make_xy(df: pd.DataFrame, y_col: str, x_cols: list[str]):
    y = df[y_col].astype(float)
    X = df[x_cols].astype(float)
    return X, y