import sys
from pathlib import Path

# Add the ".../JPM_Question4/src" directory to the import path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


from JPM_Q4.part1_rf.train import train
if __name__ == "__main__":
    train()