import tensorflow as tf
from .config import Params
from .dynamics import sample_z_next, profit_pi, adj_cost

DTYPE = tf.float32

@tf.function
def bellman_residual(P: Params, Vnet, Pnet, k, z, n_mc: int):
    beta = tf.constant(P.beta, DTYPE)

    V = Vnet(k, z)                         # [B,1]
    kp = Pnet(k, z)                        # [B,1]
    I = kp - (1.0 - P.delta) * k           # [B,1]

    flow = profit_pi(P, k, z) - adj_cost(P, I) - I

    z_next = sample_z_next(P, z, n_mc)     # [B,n_mc]
    kp_mc = tf.tile(kp, [1, n_mc])         # [B,n_mc]

    V_next = Vnet(tf.reshape(kp_mc, [-1, 1]), tf.reshape(z_next, [-1, 1]))
    V_next = tf.reshape(V_next, [-1, n_mc])
    EV_next = tf.reduce_mean(V_next, axis=1, keepdims=True)

    target = flow + beta * EV_next
    R = V - target
    aux = {"V": V, "kp": kp, "I": I, "flow": flow, "EV_next": EV_next, "target": target}
    return R, aux

@tf.function
def loss_fn(P: Params, Vnet, Pnet, k, z, n_mc: int, l2_reg: float = 1e-8):
    R, aux = bellman_residual(P, Vnet, Pnet, k, z, n_mc)
    mse = tf.reduce_mean(tf.square(R))
    l2 = tf.add_n([tf.nn.l2_loss(v) for v in Vnet.trainable_variables + Pnet.trainable_variables])
    return mse + l2_reg * l2, mse, aux