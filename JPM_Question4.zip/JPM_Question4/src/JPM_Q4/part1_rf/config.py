from dataclasses import dataclass

@dataclass(frozen=True)
class Params:
    # preferences / discounting
    r: float = 0.04
    theta: float = 0.7
    delta: float = 0.15
    phi: float = 0.01

    # shock process: log z' = rho log z + eps
    rho: float = 0.7
    sigma_eps: float = 0.15

    # bounds
    k_min: float = 1e-6
    k_max: float = 200.0
    z_min: float = 1e-4
    z_max: float = 50.0

    @property
    def beta(self) -> float:
        return 1.0 / (1.0 + self.r)