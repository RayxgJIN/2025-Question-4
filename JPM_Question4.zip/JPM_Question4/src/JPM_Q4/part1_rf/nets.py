# src/jpm_q4/part1_rf/nets.py
import tensorflow as tf
from .config import Params

DTYPE = tf.float32

def make_mlp(out_dim, hidden=(256, 256), act="tanh", name="mlp"):
    layers = []
    for h in hidden:
        layers.append(tf.keras.layers.Dense(h, activation=act))
    layers.append(tf.keras.layers.Dense(out_dim, activation=None))
    return tf.keras.Sequential(layers, name=name)

class ValueNet(tf.keras.Model):
    def __init__(self, P: Params):
        super().__init__()
        self.P = P
        self.body = make_mlp(1, hidden=(256, 256), act="tanh", name="V_body")

    @tf.function
    def call(self, k, z):
        x = tf.concat([k, z], axis=1)
        return self.body(x)

class PolicyNet(tf.keras.Model):
    """
    IMPORTANT FIX:
    Enforce I >= 0 by making k' = (1-delta)k + softplus(increment).
    This prevents the negative-investment pathology you observed.
    """
    def __init__(self, P: Params):
        super().__init__()
        self.P = P
        self.body = make_mlp(1, hidden=(256, 256), act="tanh", name="Kp_body")

    @tf.function
    def call(self, k, z):
        x = tf.concat([k, z], axis=1)
        raw = self.body(x)
        increment = tf.nn.softplus(raw)  # >= 0
        kp = (1.0 - self.P.delta) * k + increment
        kp = tf.clip_by_value(kp, self.P.k_min, self.P.k_max)
        return kp