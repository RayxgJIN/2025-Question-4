# src/jpm_q4/part1_rf/dynamics.py
import numpy as np
import tensorflow as tf
from .config import Params

DTYPE = tf.float32

@tf.function
def sample_z_next(P: Params, z, n_mc: int):
    z = tf.clip_by_value(z, P.z_min, P.z_max)
    logz = tf.math.log(z)
    eps = tf.random.normal([tf.shape(z)[0], n_mc], mean=0.0, stddev=P.sigma_eps, dtype=DTYPE)
    logz_next = P.rho * logz + eps
    z_next = tf.exp(logz_next)
    return tf.clip_by_value(z_next, P.z_min, P.z_max)

@tf.function
def profit_pi(P: Params, k, z):
    k = tf.clip_by_value(k, P.k_min, P.k_max)
    z = tf.clip_by_value(z, P.z_min, P.z_max)
    return z * tf.pow(k, P.theta)

@tf.function
def adj_cost(P: Params, I):
    return 0.5 * P.phi * tf.square(I)

def sample_states(P: Params, batch_size: int, k_log_range=(-2.0, 4.5), z_log_range=(-1.0, 1.0), seed=None):
    rng = np.random.default_rng(seed)
    logk = rng.uniform(k_log_range[0], k_log_range[1], size=(batch_size, 1)).astype(np.float32)
    logz = rng.uniform(z_log_range[0], z_log_range[1], size=(batch_size, 1)).astype(np.float32)
    k = np.clip(np.exp(logk), P.k_min, P.k_max)
    z = np.clip(np.exp(logz), P.z_min, P.z_max)
    return tf.convert_to_tensor(k, DTYPE), tf.convert_to_tensor(z, DTYPE)