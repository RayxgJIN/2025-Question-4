# src/jpm_q4/part1_rf/train.py
import numpy as np
import tensorflow as tf

from .config import Params
from .dynamics import sample_states
from .nets import ValueNet, PolicyNet
from .residuals import loss_fn

def train(
    P: Params = Params(),
    steps: int = 10_000,
    batch_size: int = 4096,
    n_mc_train: int = 16,
    lr: float = 2e-4,
    grad_clip: float = 1.0,
    print_every: int = 500,
    seed: int = 123,
):
    tf.keras.utils.set_random_seed(seed)
    rng = np.random.default_rng(seed)

    Vnet = ValueNet(P)
    Pnet = PolicyNet(P)

    # build networks
    k0, z0 = sample_states(P, 4, seed=0)
    _ = Vnet(k0, z0)
    _ = Pnet(k0, z0)

    opt = tf.keras.optimizers.Adam(learning_rate=lr)

    for step in range(1, steps + 1):
        k, z = sample_states(P, batch_size, seed=rng.integers(1, 1_000_000))
        with tf.GradientTape() as tape:
            L, mse, aux = loss_fn(P, Vnet, Pnet, k, z, n_mc_train)

        vars_ = Vnet.trainable_variables + Pnet.trainable_variables
        grads = tape.gradient(L, vars_)
        grads, _ = tf.clip_by_global_norm(grads, grad_clip)
        opt.apply_gradients(zip(grads, vars_))

        if step % print_every == 0 or step == 1:
            kp = aux["kp"]
            I = aux["I"]
            print(
                f"step {step:6d} | loss {float(L):.4e} | bellman_mse {float(mse):.4e} "
                f"| kp mean {float(tf.reduce_mean(kp)):.3f} | I mean {float(tf.reduce_mean(I)):.3f}"
            )

    return {"Vnet": Vnet, "Pnet": Pnet}