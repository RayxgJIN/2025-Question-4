import numpy as np
from JPM_Q4.part2_gmm_smm.config import Params, EstimationSettings
from JPM_Q4.part2_gmm_smm.simulate import simulate_ar1
from JPM_Q4.part2_gmm_smm.moments import empirical_moments

def test_simulate_shape():
    P = Params(rho=0.7, sigma=0.2)
    S = EstimationSettings(T=50, N=100, seed=0)
    x = simulate_ar1(P, S)
    assert x.shape == (100, 50)

def test_moments_finite():
    x = np.random.default_rng(0).normal(size=(200, 30))
    m = empirical_moments(x)
    assert m.shape == (3,)
    assert np.isfinite(m).all()