import tensorflow as tf
from JPM_Q4.part1_rf.config import Params
from JPM_Q4.part1_rf.nets import ValueNet, PolicyNet
from JPM_Q4.part1_rf.dynamics import sample_states
from JPM_Q4.part1_rf.residuals import bellman_residual

def test_bellman_residual_shape_and_finite():
    P = Params()
    Vnet = ValueNet(P)
    Pnet = PolicyNet(P)

    k, z = sample_states(P, batch_size=64, seed=0)
    _ = Vnet(k, z)
    _ = Pnet(k, z)

    R, aux = bellman_residual(P, Vnet, Pnet, k, z, n_mc=4)
    assert R.shape == (64, 1)
    tf.debugging.assert_all_finite(R, "Residual contains NaN/Inf")

def test_investment_nonnegative():
    P = Params()
    Pnet = PolicyNet(P)
    k, z = sample_states(P, batch_size=128, seed=1)
    kp = Pnet(k, z)
    I = kp - (1.0 - P.delta) * k
    assert float(tf.reduce_min(I)) >= -1e-6