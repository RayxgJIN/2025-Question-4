import tensorflow as tf
from JPM_Q4.part1_risky_debt.config import Params
from JPM_Q4.part1_risky_debt.nets import ValueNet, PolicyNet
from JPM_Q4.part1_risky_debt.dynamics import sample_states, DTYPE
from JPM_Q4.part1_risky_debt.residuals import bellman_residual

def test_shapes_and_finite():
    P = Params()
    Vnet = ValueNet(P)
    Pnet = PolicyNet(P)

    k, z = sample_states(P, 32, seed=0)
    b = tf.zeros([32, 1], dtype=DTYPE)
    _ = Vnet(k, z, b)
    _ = Pnet(k, z, b)

    R, aux = bellman_residual(P, Vnet, Pnet, k, z, b, n_mc=4)
    assert R.shape == (32, 1)
    tf.debugging.assert_all_finite(R, "NaN/Inf in residual")

def test_kprime_bounds():
    P = Params()
    Pnet = PolicyNet(P)
    k, z = sample_states(P, 64, seed=1)
    b = tf.zeros([64, 1], dtype=DTYPE)
    kp, bp = Pnet(k, z, b)
    assert float(tf.reduce_min(kp)) >= P.k_min - 1e-6
    assert float(tf.reduce_max(kp)) <= P.k_max + 1e-6