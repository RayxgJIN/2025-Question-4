import numpy as np
from JPM_Q4.bonus_ceo_board.model import ols_fit, ols_predict

def test_ols_recovers_linear_relation():
    rng = np.random.default_rng(0)
    X = rng.normal(size=(500, 2))
    true_beta = np.array([1.0, 2.0, -3.0])  # intercept + coefs
    y = true_beta[0] + X @ true_beta[1:] + 0.01 * rng.normal(size=500)

    beta = ols_fit(X, y)
    yhat = ols_predict(X, beta)

    assert beta.shape == (3,)
    assert np.mean((y - yhat) ** 2) < 0.01
