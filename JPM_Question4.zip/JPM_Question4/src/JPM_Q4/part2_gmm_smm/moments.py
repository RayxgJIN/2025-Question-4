# src/jpm_q4/part2_gmm_smm/moments.py
import numpy as np

def empirical_moments(x: np.ndarray):
    # example moments: mean, variance, lag1 autocov
    m1 = x.mean()
    m2 = x.var()
    ac1 = np.mean(x[:, 1:] * x[:, :-1])
    return np.array([m1, m2, ac1], dtype=float)