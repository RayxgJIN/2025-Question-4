# src/jpm_q4/part2_gmm_smm/estimate.py
import numpy as np
from .config import Params, EstimationSettings
from .simulate import simulate_ar1
from .moments import empirical_moments
from .criterion import gmm_objective

def estimate_from_data(x_data: np.ndarray, rho_grid=None, sigma_grid=None, settings: EstimationSettings = EstimationSettings()):
    if rho_grid is None:
        rho_grid = np.linspace(0.1, 0.95, 18)
    if sigma_grid is None:
        sigma_grid = np.linspace(0.05, 0.5, 10)

    m_data = empirical_moments(x_data)

    best = (np.inf, None)
    for rho in rho_grid:
        for sigma in sigma_grid:
            P = Params(rho=float(rho), sigma=float(sigma))
            x_sim = simulate_ar1(P, settings)
            m_sim = empirical_moments(x_sim)
            obj = gmm_objective(m_sim, m_data)
            if obj < best[0]:
                best = (obj, P)
    return {"objective": best[0], "params": best[1]}