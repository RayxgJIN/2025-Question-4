import numpy as np
from JPM_Q4.part2_gmm_smm.config import Params, EstimationSettings
from JPM_Q4.part2_gmm_smm.simulate import simulate_ar1
from JPM_Q4.part2_gmm_smm.estimate import estimate_from_data

if __name__ == "__main__":
    P_true = Params(rho=0.8, sigma=0.2)
    S = EstimationSettings(T=200, N=2000, seed=0)
    x_data = simulate_ar1(P_true, S)
    out = estimate_from_data(x_data, settings=S)
    print(out)