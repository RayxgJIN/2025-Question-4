# src/jpm_q4/part2_gmm_smm/config.py
from dataclasses import dataclass

@dataclass(frozen=True)
class Params:
    # Put the structural parameters you estimate here
    rho: float = 0.7
    sigma: float = 0.15

@dataclass(frozen=True)
class EstimationSettings:
    T: int = 200
    N: int = 2000
    seed: int = 0