# src/jpm_q4/part2_gmm_smm/simulate.py
import numpy as np
from .config import Params, EstimationSettings

def simulate_ar1(P: Params, S: EstimationSettings):
    rng = np.random.default_rng(S.seed)
    x = np.zeros((S.N, S.T), dtype=float)
    eps = rng.normal(0.0, P.sigma, size=(S.N, S.T))
    for t in range(1, S.T):
        x[:, t] = P.rho * x[:, t-1] + eps[:, t]
    return x