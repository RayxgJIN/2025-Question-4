# src/jpm_q4/part2_gmm_smm/criterion.py
import numpy as np

def gmm_objective(m_model: np.ndarray, m_data: np.ndarray, W: np.ndarray | None = None):
    d = (m_model - m_data).reshape(-1, 1)
    if W is None:
        W = np.eye(len(m_data))
    return float(d.T @ W @ d)