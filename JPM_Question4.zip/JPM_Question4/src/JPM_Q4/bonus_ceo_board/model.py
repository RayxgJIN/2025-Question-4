# src/jpm_q4/bonus_ceo_board/model.py
import numpy as np

def ols_fit(X: np.ndarray, y: np.ndarray):
    # add intercept
    X1 = np.column_stack([np.ones(len(X)), X])
    beta, *_ = np.linalg.lstsq(X1, y, rcond=None)
    return beta

def ols_predict(X: np.ndarray, beta: np.ndarray):
    X1 = np.column_stack([np.ones(len(X)), X])
    return X1 @ beta