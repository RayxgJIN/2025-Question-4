# src/jpm_q4/bonus_ceo_board/train.py
import numpy as np
from .model import ols_fit, ols_predict

def rmse(y, yhat):
    y = np.asarray(y)
    yhat = np.asarray(yhat)
    return float(np.sqrt(np.mean((y - yhat) ** 2)))

def fit_and_score(X, y):
    beta = ols_fit(X, y)
    yhat = ols_predict(X, beta)
    return {"beta": beta, "rmse": rmse(y, yhat)}