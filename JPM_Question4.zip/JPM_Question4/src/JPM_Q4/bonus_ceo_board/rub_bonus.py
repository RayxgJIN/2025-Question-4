import numpy as np
from JPM_Q4.bonus_ceo_board.train import fit_and_score

if __name__ == "__main__":
    rng = np.random.default_rng(0)
    X = rng.normal(size=(200, 3))
    y = 1.0 + X @ np.array([0.5, -0.2, 0.1]) + rng.normal(scale=0.1, size=200)
    print(fit_and_score(X, y))