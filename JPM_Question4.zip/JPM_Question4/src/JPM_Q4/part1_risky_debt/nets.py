# src/jpm_q4/part1_risky_debt/nets.py
import tensorflow as tf
from .config import Params

def make_mlp(out_dim, hidden=(256, 256), act="tanh", name="mlp"):
    layers = []
    for h in hidden:
        layers.append(tf.keras.layers.Dense(h, activation=act))
    layers.append(tf.keras.layers.Dense(out_dim, activation=None))
    return tf.keras.Sequential(layers, name=name)

class ValueNet(tf.keras.Model):
    def __init__(self, P: Params):
        super().__init__()
        self.P = P
        self.body = make_mlp(1, name="V_body")

    @tf.function
    def call(self, k, z, b):
        x = tf.concat([k, z, b], axis=1)
        return self.body(x)

class PolicyNet(tf.keras.Model):
    """
    Example: chooses next capital k' and next debt b'.
    You must map this to your original risky debt section.
    """
    def __init__(self, P: Params):
        super().__init__()
        self.P = P
        self.kp_head = make_mlp(1, name="kp_head")
        self.bp_head = make_mlp(1, name="bp_head")

    @tf.function
    def call(self, k, z, b):
        x = tf.concat([k, z, b], axis=1)

        raw_kp = self.kp_head(x)
        kp = (1.0 - self.P.delta) * k + tf.nn.softplus(raw_kp)
        kp = tf.clip_by_value(kp, self.P.k_min, self.P.k_max)

        raw_bp = self.bp_head(x)
        bp = raw_bp  # you may want softplus or clipping depending on your model

        return kp, bp