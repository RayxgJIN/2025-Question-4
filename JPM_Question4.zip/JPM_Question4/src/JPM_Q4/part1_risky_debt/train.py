# src/jpm_q4/part1_risky_debt/train.py
import numpy as np
import tensorflow as tf

from .config import Params
from .nets import ValueNet, PolicyNet
from .residuals import loss_fn
from .dynamics import sample_states, DTYPE

def train(P: Params = Params(), steps=5000, batch_size=2048, n_mc=8, lr=2e-4, seed=0, print_every=500):
    tf.keras.utils.set_random_seed(seed)
    rng = np.random.default_rng(seed)

    Vnet = ValueNet(P)
    Pnet = PolicyNet(P)

    # init / build
    k, z = sample_states(P, 4, seed=1)
    b = tf.zeros([4, 1], dtype=DTYPE)
    _ = Vnet(k, z, b)
    _ = Pnet(k, z, b)

    opt = tf.keras.optimizers.Adam(lr)

    for step in range(1, steps + 1):
        k, z = sample_states(P, batch_size, seed=rng.integers(1, 1_000_000))
        b = tf.zeros([batch_size, 1], dtype=DTYPE)  # replace with your b sampling

        with tf.GradientTape() as tape:
            L, aux = loss_fn(P, Vnet, Pnet, k, z, b, n_mc)

        vars_ = Vnet.trainable_variables + Pnet.trainable_variables
        grads = tape.gradient(L, vars_)
        opt.apply_gradients(zip(grads, vars_))

        if step % print_every == 0 or step == 1:
            print(f"step {step:6d} | loss {float(L):.4e}")

    return {"Vnet": Vnet, "Pnet": Pnet}