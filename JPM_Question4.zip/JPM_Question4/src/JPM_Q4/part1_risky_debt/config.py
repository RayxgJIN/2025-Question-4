# src/jpm_q4/part1_risky_debt/config.py
from dataclasses import dataclass

@dataclass(frozen=True)
class Params:
    # discounting / production
    r: float = 0.04
    theta: float = 0.7
    delta: float = 0.15
    phi: float = 0.01

    # productivity shock
    rho: float = 0.7
    sigma_eps: float = 0.15

    # debt / pricing (YOU will map to your script’s meaning)
    recovery: float = 0.4     # e.g., fraction recovered in default
    coupon: float = 1.0       # placeholder, if you use coupon bonds
    face: float = 1.0         # placeholder, if you use face value

    # bounds
    k_min: float = 1e-6
    k_max: float = 200.0
    z_min: float = 1e-4
    z_max: float = 50.0

    @property
    def beta(self) -> float:
        return 1.0 / (1.0 + self.r)