# src/jpm_q4/part1_risky_debt/pricing.py
import tensorflow as tf
from .config import Params

@tf.function
def default_indicator(P: Params, state_vars):
    """
    Replace with your model’s default condition.
    Example placeholder: never default.
    """
    return tf.zeros([tf.shape(state_vars)[0], 1], dtype=tf.float32)

@tf.function
def bond_price(P: Params, default_prob):
    """
    Replace with your pricing equation.
    Example placeholder: risk-free price adjusted for default + recovery.
    """
    beta = tf.constant(P.beta, tf.float32)
    return beta * ((1.0 - default_prob) + default_prob * P.recovery)