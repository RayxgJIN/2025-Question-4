from JPM_Q4.part1_risky_debt.train import train
if __name__ == "__main__":
    train()