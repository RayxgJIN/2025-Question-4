# src/jpm_q4/part1_risky_debt/residuals.py
import tensorflow as tf
from .config import Params
from .dynamics import profit_pi, adj_cost, sample_z_next
from .pricing import default_indicator, bond_price

@tf.function
def bellman_residual(P: Params, Vnet, Pnet, k, z, b, n_mc: int):
    beta = tf.constant(P.beta, tf.float32)

    V = Vnet(k, z, b)
    kp, bp = Pnet(k, z, b)
    I = kp - (1.0 - P.delta) * k

    # placeholder: incorporate debt cashflows how your script does it
    flow = profit_pi(P, k, z) - adj_cost(P, I) - I

    # price bond based on default indicator/probability (placeholder)
    d = default_indicator(P, tf.concat([k, z, b], axis=1))
    q = bond_price(P, d)  # placeholder

    # continuation
    z_next = sample_z_next(P, z, n_mc)
    kp_mc = tf.tile(kp, [1, n_mc])
    bp_mc = tf.tile(bp, [1, n_mc])

    V_next = Vnet(
        tf.reshape(kp_mc, [-1, 1]),
        tf.reshape(z_next, [-1, 1]),
        tf.reshape(bp_mc, [-1, 1]),
    )
    V_next = tf.reshape(V_next, [-1, n_mc])
    EV_next = tf.reduce_mean(V_next, axis=1, keepdims=True)

    target = flow + beta * EV_next
    R = V - target
    aux = {"kp": kp, "bp": bp, "I": I, "q": q, "flow": flow}
    return R, aux

@tf.function
def loss_fn(P: Params, Vnet, Pnet, k, z, b, n_mc: int):
    R, aux = bellman_residual(P, Vnet, Pnet, k, z, b, n_mc)
    mse = tf.reduce_mean(tf.square(R))
    return mse, aux